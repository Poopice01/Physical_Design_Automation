//Uncomment the following code to DISABLE debug information
//#define NDEBUG

#include <cassert>
