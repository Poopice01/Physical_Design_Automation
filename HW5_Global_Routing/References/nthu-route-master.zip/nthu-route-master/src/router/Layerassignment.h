#ifndef INC_LAYER_ASSIGNMENT_H
#define INC_LAYER_ASSIGNMENT_H

extern void Layer_assignment();

#endif //INC_LAYER_ASSIGNMENT_H
